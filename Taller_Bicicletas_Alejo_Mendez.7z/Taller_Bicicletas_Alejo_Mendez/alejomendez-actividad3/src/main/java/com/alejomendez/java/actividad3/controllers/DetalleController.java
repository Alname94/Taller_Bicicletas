package com.alejomendez.java.actividad3.controllers;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import com.alejomendez.java.actividad3.services.DetalleService;
import com.alejomendez.java.actividad3.services.PresupuestoService;
import com.alejomendez.java.actividad3.services.RepuestoService;

@Controller
public class DetalleController {
    private final DetalleService detalleService;
    private final PresupuestoService presupuestoService;
    private final RepuestoService repuestoService;

    public DetalleController(DetalleService detalleService, PresupuestoService presupuestoService,
            RepuestoService repuestoService) {
        this.detalleService = detalleService;
        this.presupuestoService = presupuestoService;
        this.repuestoService = repuestoService;
    }

    
}
