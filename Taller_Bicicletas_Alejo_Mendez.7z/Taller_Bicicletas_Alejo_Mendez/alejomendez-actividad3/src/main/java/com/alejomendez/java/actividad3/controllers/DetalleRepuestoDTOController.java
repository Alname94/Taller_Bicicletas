package com.alejomendez.java.actividad3.controllers;

import org.springframework.stereotype.Controller;

import com.alejomendez.java.actividad3.services.DetalleRepuestoDTOService;

@Controller
public class DetalleRepuestoDTOController {
    private final DetalleRepuestoDTOService detalleRepuestoDTOService;

    public DetalleRepuestoDTOController(DetalleRepuestoDTOService detalleRepuestoDTOService) {
        this.detalleRepuestoDTOService = detalleRepuestoDTOService;
    }
}
