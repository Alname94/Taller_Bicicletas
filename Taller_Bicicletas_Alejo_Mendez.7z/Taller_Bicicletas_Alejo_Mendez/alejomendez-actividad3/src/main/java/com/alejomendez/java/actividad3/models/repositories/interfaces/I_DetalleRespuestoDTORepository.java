package com.alejomendez.java.actividad3.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.alejomendez.java.actividad3.models.dtos.DetalleRepuestoDTO;

public interface I_DetalleRespuestoDTORepository {
    List<DetalleRepuestoDTO> findByPresupuestoDTO(int presupuestoNumero) throws SQLException;
}
