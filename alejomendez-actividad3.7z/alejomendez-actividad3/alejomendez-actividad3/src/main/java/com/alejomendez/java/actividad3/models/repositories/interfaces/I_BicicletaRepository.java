package com.alejomendez.java.actividad3.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.alejomendez.java.actividad3.models.entities.Bicicleta;

public interface I_BicicletaRepository {
    void create(Bicicleta bicicleta) throws SQLException;
    Bicicleta findById(int id) throws SQLException;
    List<Bicicleta> findAll() throws SQLException;
    int update(Bicicleta bicicleta) throws SQLException;
    int delete(int id) throws SQLException;
    Bicicleta findByPresupuesto(int numero) throws SQLException;
    List<Bicicleta> findByCliente(int id) throws SQLException;
}
