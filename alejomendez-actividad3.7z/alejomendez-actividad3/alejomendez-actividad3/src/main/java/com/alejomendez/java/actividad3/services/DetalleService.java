package com.alejomendez.java.actividad3.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alejomendez.java.actividad3.models.entities.Detalle;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_DetalleRepository;

@Service
public class DetalleService {
    private final I_DetalleRepository detalleRepository;

    public DetalleService(I_DetalleRepository detalleRepository) {
        this.detalleRepository = detalleRepository;
    }

    /**
     * Obtiene una lista de todos los detalles
     * @return
     * @throws SQLException
     */
    public List<Detalle> obtenerTodosLosDetalles() throws SQLException {
        return detalleRepository.findAll();
    }

    /**
     * Se utiliza para agregar un repuesto dentro de un presupuesto, el detalle creado contiene el número de presupuesto y el código del repuesto
     * @param detalle
     * @return
     * @throws SQLException
     */
    public Detalle guardarDetalle(Detalle detalle) throws SQLException {
        detalleRepository.create(detalle);
        return detalle;
    }

    /**
     * Busca los detalles por numero de presupuesto
     * @param numero
     * @return
     * @throws SQLException
     */
    public List<Detalle> buscarDetallePorPresupuesto(int presupuestoNumero) throws SQLException {
        return detalleRepository.findByPresupuesto(presupuestoNumero);
    }

    public List<Detalle> buscarDetallesPorRepuesto(int repuestoCodigo) throws SQLException {
        return detalleRepository.findByRepuesto(repuestoCodigo);
    }
}
