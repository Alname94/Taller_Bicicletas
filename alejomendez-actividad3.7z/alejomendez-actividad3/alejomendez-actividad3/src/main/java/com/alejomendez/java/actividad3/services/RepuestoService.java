package com.alejomendez.java.actividad3.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alejomendez.java.actividad3.models.entities.Repuesto;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_RepuestoRepository;

@Service
public class RepuestoService {
    private final I_RepuestoRepository repuestoRepository;

    public RepuestoService(I_RepuestoRepository repuestoRepository) {
        this.repuestoRepository = repuestoRepository;
    }

    /**
     * Obtiene una lista de todos los repuestos
     * @return
     * @throws SQLException
     */
    public List<Repuesto> obtenerTodosLosRepuestos() throws SQLException {
        return repuestoRepository.findAll();
    }


    //ESTE ME MÉTODO ME SACÓ MUCHO TIEMPO. Al ser código una PK no auto incrementable, al momento de querer crear un nuevo Repuesto, según la validación del if,
    //se detectaba que el código pasado como parámetro era mayor a 0 por lo que ejecutaba .update() y no creaba el repuesto.
    //Así mismo, si quería crear un nuevo Repuesto y pasaba como código uno ya existente, no se detectaba un error de PK duplicada, sino que actualizaba el repuesto ya
    //existente con los nuevos datos.
    //En principio voy a separar .update() y .create() en dos métodos distintos. 
    /**
     * Guarda un repuesto o lo actualiza si el repuesto ya existe
     * @param repuesto
     * @return
     * @throws SQLException
     */
    // public Repuesto guardarRepuesto(Repuesto repuesto) throws SQLException {
    //     if(repuesto.getCodigo()!=0 && repuestoRepository.findByCodigo(repuesto.getCodigo())!=null){
    //         repuestoRepository.update(repuesto);
    //     }else{
    //         repuestoRepository.create(repuesto);
    //     }
    //     return repuesto;
    // }

    public Repuesto guardarRepuesto(Repuesto repuesto) throws SQLException {
        repuestoRepository.update(repuesto);
        return repuesto;
    }

    public Repuesto crearRepuesto(Repuesto repuesto) throws SQLException {
        repuestoRepository.create(repuesto);
        return repuesto;
    }

    /**
     * Busca un repuesto por su codigo
     * @param codigo
     * @return
     * @throws SQLException
     */
    public Repuesto buscarRepuestoPorCodigo(int codigo) throws SQLException {
        return repuestoRepository.findByCodigo(codigo);
    }

    /**
     * Elimina un repuesto por codigo
     * @param codigo
     * @return
     * @throws SQLException
     */
    public int eliminarRepuesto(int codigo) throws SQLException {
        return repuestoRepository.delete(codigo);
    }

    /**
     * Lista los repuestos que se encuentren en el presupuesto pasado como parametro
     * @param numero
     * @return
     * @throws SQLException
     */
    public List<Repuesto> buscarRepuestoPorPresupuesto(int numero) throws SQLException {
        return repuestoRepository.findByPresupuesto(numero); 
    }
}
